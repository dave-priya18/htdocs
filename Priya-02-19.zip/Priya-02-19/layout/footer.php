<?php


?>
<div id="content_footer"></div>
    <div id="footer">
      Copyright &copy; colour_red | <a href="http://validator.w3.org/check?uri=referer">HTML5</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | <a href="http://www.html5webtemplates.co.uk">Website Templates</a>
    </div>
  </div>
</body>
</html>
